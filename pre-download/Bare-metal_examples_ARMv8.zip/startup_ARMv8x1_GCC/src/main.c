/*
 * ARMv8 - Main
 *
 * Copyright (c) 2011-2016 ARM Ltd.  All rights reserved.
 *
 */

#include <stdlib.h>
#include <stdio.h>

// declaration of 'extern' functions
extern void init_timer(void);    // in timer_interrupts.c


__attribute__((noreturn)) int main(void)
{
    printf("\nDS-5 ARMv8 Startup Example, using Linaro bare-metal GCC\n\n");
    init_timer();

    for(;;) {} //loop forever
}
