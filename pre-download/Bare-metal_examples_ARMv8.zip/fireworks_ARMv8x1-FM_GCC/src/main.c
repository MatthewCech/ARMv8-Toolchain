/*
 * ARMv8 - Main
 *
 * Copyright (c) 2011-2016 ARM Ltd.  All rights reserved.
 *
 */

#include <stdlib.h>
#include <stdio.h>

// declaration of 'extern' functions
extern void setup_screen(void);  // in fireworks.c
extern void init_timer(void);    // in timer_interrupts.c
extern void fireworks(void);     // in fireworks.c


__attribute__((noreturn)) int main(void)
{
    printf("\nDS-5 ARMv8 Fireworks Example, using Linaro bare-metal GCC\n\n");
    printf("Click on USERSW1 to stop/restart the Banner\n\n");
    setup_screen();    // in fireworks.c
    init_timer();

    //run the fireworks!!
    fireworks();

    for(;;) {} //loop forever
}
